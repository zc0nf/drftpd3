# jFLAC

[FLAC](https://xiph.org/flac/) codec for Java.

Fork of the original SourceForge project: http://jflac.sourceforge.net/

[![Build Status](https://travis-ci.org/nguillaumin/jflac.svg)](https://travis-ci.org/nguillaumin/jflac)
[![Coverity Status](https://scan.coverity.com/projects/10205/badge.svg)](https://scan.coverity.com/projects/nguillaumin-jflac)
