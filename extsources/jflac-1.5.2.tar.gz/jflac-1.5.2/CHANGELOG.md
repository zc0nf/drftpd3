# jFLAC Changelog

## v1.5.2 (2017-05-29)

* Fixed license (from Apache to LGPL), see [LICENSE.md](LICENSE.md) for details

## v1.5.1 (2016-11-18)

* Various code quality fixes using FindBugs & Coverity
* Fix audio stream playing (example: `SndPlayer.java`) thanks to @wolfgangasdf

## v1.5.0 (2016-09-02)

* First release to be published on Maven Central
* Packages have been renamed to `org.jflac.*`
